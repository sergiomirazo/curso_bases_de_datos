-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Servidor: sql211.byetcluster.com
-- Tiempo de generación: 28-09-2024 a las 19:24:26
-- Versión del servidor: 10.6.19-MariaDB
-- Versión de PHP: 7.2.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `if0_37306581_DeadWords`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `frases`
--

CREATE TABLE `frases` (
  `id` int(3) UNSIGNED NOT NULL,
  `texto` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `frases`
--

INSERT INTO `frases` (`id`, `texto`) VALUES
(1, 'Serás devorado por un enjambre de patitos de goma voladores.'),
(2, 'Morirás asfixiado en una nube de algodón de azúcar gigante.'),
(3, 'Un piano caerá sobre ti mientras intentas tocar la flauta.'),
(4, 'Serás arrastrado por una estampida de caracoles enojados.'),
(5, 'Te atrapará una licuadora gigante mientras intentas hacer una ensalada.'),
(6, 'Un cactus parlante te retará a un duelo de miradas... y perderás.'),
(7, 'Serás transformado en gelatina por una máquina de refrescos defectuosa.'),
(8, 'Serás aplastado por una torre de panqueques en una competencia de cocina.'),
(9, 'Un tornado de peluches te lanzará al espacio exterior.'),
(10, 'Morirás congelado dentro de un cubo de hielo gigante en una fiesta de verano.'),
(11, 'Serás tragado por un hoyo negro que aparece misteriosamente en tu baño.'),
(12, 'Serás atacado por un ejército de flamencos rosa en busca de venganza.'),
(13, 'Serás abducido por extraterrestres que te confunden con su líder perdido.'),
(14, 'Te derretirás por completo al ver un meme extremadamente divertido.'),
(15, 'Serás aplastado por una enorme bola de chicle mientras caminas por la calle.'),
(16, 'Te ahogarás en una piscina de sopa de tomate cuando intentas nadar en ella.'),
(17, 'Unos calcetines rebeldes cobrarán vida y te asfixiarán mientras duermes.'),
(18, 'Serás perseguido hasta el fin del mundo por una manada de unicornios furiosos.'),
(19, 'Te convertirás en una nube de polvo al intentar abrazar un maniquí.'),
(20, 'Serás tragado por una ballena voladora que confunde tu casa con el océano.'),
(21, 'Caerás al vacío cuando un puente arcoíris desaparezca bajo tus pies.'),
(22, 'Serás aplastado por una pila de sombreros que caen del cielo.'),
(23, 'Un espejo mágico te lanzará a otra dimensión donde te evaporarás.'),
(24, 'Un ventilador gigante te lanzará al espacio mientras intentas refrescarte.'),
(25, 'Serás desintegrado por una máquina de fax que cree que eres un documento.'),
(26, 'Serás aplastado por un globo de cumpleaños gigante que explota inesperadamente.'),
(27, 'Un grupo de abejas con corbatas te invitará a una fiesta... de la que nunca saldrás.'),
(28, 'Serás empujado a un volcán en erupción por un pingüino enfurecido.'),
(29, 'Te resbalarás con una cáscara de plátano y caerás en un agujero infinito.'),
(30, 'Serás absorbido por una aspiradora gigante mientras intentas limpiar el suelo.'),
(31, 'Serás transformado en queso por una máquina de fondue defectuosa.'),
(32, 'Serás aplastado por un dinosaurio inflable en un parque temático.'),
(33, 'Un oso polar en patines te lanzará a través de una ventana mientras patinas sobre hielo.'),
(34, 'Te quedarás atrapado en una máquina expendedora que misteriosamente te absorbe.'),
(35, 'Un robot gigante te confundirá con una pieza de ajedrez y te aplastará.'),
(36, 'Serás lanzado al espacio por una catapulta de helado mal calibrada.'),
(37, 'Morirás de risa al escuchar el chiste más malo del mundo contado por una ardilla.'),
(38, 'Serás atrapado por una planta carnívora gigante mientras riegas tu jardín.'),
(39, 'Un trombón gigante te absorberá mientras intentas tocar una melodía.'),
(40, 'Te convertirás en una estatua de gelatina por culpa de un hechizo mal pronunciado.'),
(41, 'Serás atrapado en un torbellino de confeti hasta desaparecer.'),
(42, 'Serás sepultado por una montaña de libros que caen de un estante en la biblioteca.'),
(43, 'Una nube de pelusa de ombligo cobrará vida y te asfixiará.'),
(44, 'Un dragón te convertirá en carbón mientras intentas encender la barbacoa.'),
(45, 'Serás abducido por un grupo de ovnis que confunden tu sombra con un alienígena.'),
(46, 'Un gigante de pan de jengibre te morderá hasta desaparecer.'),
(47, 'Un tiburón volador te tragará mientras paseas en la playa.'),
(48, 'Morirás al intentar volar con globos llenos de helio que explotan en el cielo.'),
(49, 'Serás aplastado por una montaña de zapatos viejos que caen del techo.'),
(50, 'Serás absorbido por una tormenta de pelucas en una convención de moda.'),
(51, 'Un pez dorado gigante te tragará mientras limpias su pecera.'),
(52, 'Un ventilador de techo se desprenderá y te lanzará al espacio.'),
(53, 'Serás envuelto por una manta gigante que cobra vida y te atrapa para siempre.'),
(54, 'Te quedarás atrapado en un reloj de arena gigante que nunca dejará de girar.'),
(55, 'Un tren de juguete gigante te atropellará en el patio de juegos.'),
(56, 'Serás aplastado por una rueda de queso gigante en un festival culinario.'),
(57, 'Un enjambre de globos con helio te elevará al cielo... para no volver.'),
(58, 'Serás atrapado en una burbuja gigante y te desintegrarás al estallar.'),
(59, 'Morirás al intentar batir el récord mundial de volteretas en el aire.'),
(60, 'Un castor gigante te enterrará en una presa de madera mientras paseas por el río.'),
(61, 'Una tostadora te lanzará a otra dimensión mientras intentas hacer un sándwich.'),
(62, 'Te resbalarás en una mancha de helado y caerás en un portal hacia otra realidad.'),
(63, 'Un conejo gigante te secuestrará y te llevará a su guarida subterránea.'),
(64, 'Serás convertido en piedra por una cámara de fotos encantada.'),
(65, 'Un canguro gigante te lanzará al espacio en su bolsa mientras saltas cerca de él.'),
(66, 'Serás absorbido por una espiral infinita de papel higiénico en un baño público.'),
(67, 'Serás sepultado por una avalancha de pelotas de tenis en una cancha vacía.'),
(68, 'Un grupo de robots bailarines te capturará y te obligará a bailar hasta desvanecerte.'),
(69, 'Un mono con gafas te lanzará desde la torre más alta de la ciudad.'),
(70, 'Serás empujado a una piscina de lava por un ejército de patitos de hule.'),
(71, 'Una máquina de helado te transformará en paleta mientras intentas comer.'),
(72, 'Serás abducido por un tiburón volador que confunde tu casa con el océano.'),
(73, 'Un imán gigante te atraerá hasta que te desintegres.'),
(74, 'Un muñeco de nieve gigante te congelará en medio de un desierto.'),
(75, 'Serás tragado por una nube gigante mientras intentas volar un cometa.'),
(76, 'Serás arrastrado al inframundo por una cuerda de saltar maldita.'),
(77, 'Serás lanzado a una carrera de carritos de supermercado y nunca frenarás.'),
(78, 'Un ventilador gigante te cortará en pedazos mientras intentas descansar bajo su sombra.'),
(79, 'Te quedarás atrapado en un círculo infinito de puertas giratorias.'),
(80, 'Un caimán volador te arrastrará hasta su nido en la cima de un rascacielos.'),
(81, 'Un ejército de lápices cobrará vida y te escribirá hasta desaparecer.'),
(82, 'Te sumergirás en una piscina de malvaviscos y nunca volverás a salir.'),
(83, 'Un monstruo de algodón de azúcar te atrapará mientras paseas por la feria.'),
(84, 'Serás tragado por un agujero dimensional que aparece en tu taza de café.'),
(85, 'Un dragón de chicle te pegará a la tierra para siempre.'),
(86, 'Serás empujado por un tornado de pelotas de playa hasta la estratósfera.'),
(87, 'Te derretirás bajo un sol que resulta ser una bola gigante de queso.'),
(88, 'Un grupo de ardillas te lanzará cacahuates hasta que desaparezcas.'),
(89, 'Una ola de caracoles gigantes te arrastrará al mar.'),
(90, 'Un tren de caramelo te atropellará mientras paseas por la estación.'),
(91, 'Te quedarás atrapado en un mueble gigante de IKEA que nunca lograrás armar.'),
(92, 'Serás devorado por una ola de espaguetis que cobra vida.'),
(93, 'Te aplastará un camión de galletas mientras intentas alcanzarlas.'),
(94, 'Serás absorbido por un tornado de puré de patatas voladoras.'),
(95, 'Te caerás en una trampa de gelatina y nunca podrás salir.'),
(96, 'Un enjambre de palomitas de maíz te asfixiará en una sala de cine.'),
(97, 'Serás golpeado por una lluvia de plátanos que caen del cielo.'),
(98, 'Un unicornio enfadado te lanzará al espacio por intentar acariciarlo.'),
(99, 'Te quedarás atrapado en un bucle infinito de bailar con un robot.'),
(100, 'Serás tragado por una nube de algodón de azúcar que decide volar.');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `frases`
--
ALTER TABLE `frases`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `frases`
--
ALTER TABLE `frases`
  MODIFY `id` int(3) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=101;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
