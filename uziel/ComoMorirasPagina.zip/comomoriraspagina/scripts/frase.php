<?php

header('Content-Type: text/html; charset=utf-8');
// Mostrar errores para depuración
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Datos de conexión a la base de datos
$servername = "Enlace o nombre del Servidor"; 
$username = "Aqui va el nombre del usuario"; 
$password = "Aqui va la contraseña"; 
$dbname = "Aqui va el nombre de la base de datos";
// Cambie estos datos por privacidad 

// Crear conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar la conexión
if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}

// Obtener datos del formulario
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $nombre = $_POST['nombre'];
    $numero = (int)$_POST['numero'];

    // Validar el número
    if ($numero < 1 || $numero > 100) {
        die("El número debe estar entre 1 y 100.");
    }

    // Consultar la frase correspondiente
    $sql = "SELECT texto FROM frases WHERE id = ?";
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        die("Error al preparar la consulta: " . $conn->error);
    }
    $stmt->bind_param("i", $numero);
    $stmt->execute();
    $stmt->bind_result($frase);
    $stmt->fetch();
    $stmt->close();
    $conn->close();

    // Mostrar la frase
    if ($frase) {
        echo "<h1 class='resultado'>Hola, $nombre</h1>";
        echo "<p class='resultado'>Tu muerte sera: <strong>$frase</strong></p>";
    } else {
        echo "<p>No se encontró ninguna frase para ese número.</p>";
    }
}
?>